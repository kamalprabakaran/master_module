module.exports = {
  url: "mongodb+srv://kamalprabakaran:kowsi%402601@cluster0.nxhyw.mongodb.net/masterdb?retryWrites=true&w=majority"
};
